#!/usr/bin/env python

import rospy
from sc627_helper.msg import ObsData
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math
from tf.transformations import euler_from_quaternion

# ANG_MAX = math.pi/18
ANG_MAX = math.pi
VEL_MAX = 0.15

x = 0
y = 0
theta = 0
v_x = 0
v_y = 0

x_l = 0
y_l = 0
theta_l = 0
v_x_l = 0
v_y_l = 0

x_r = 0
y_r = 0
theta_r = 0
v_x_r = 0
v_y_r = 0

def velocity_convert(x, y, theta, vel_x, vel_y):
    '''
    Robot pose (x, y, theta)  Note - theta in (0, 2pi)
    Velocity vector (vel_x, vel_y)
    '''

    # gain_ang = 1 #modify if necessary
    gain_ang = 1 #modify if necessary
    
    ang = math.atan2(vel_y, vel_x)
    if ang < 0:
        ang += 2 * math.pi
    
    ang_err = min(max(ang - theta, -ANG_MAX), ANG_MAX)

    v_lin =  min(max(math.cos(ang_err) * math.sqrt(vel_x ** 2 + vel_y ** 2), -VEL_MAX), VEL_MAX)
    v_ang = gain_ang * ang_err
    return v_lin, v_ang

def callback_odom(data):
    '''
    Get robot data
    '''
    global x, y, theta, v_x, v_y
    x = data.pose.pose.position.x
    y = data.pose.pose.position.y
    theta = euler_from_quaternion([data.pose.pose.orientation.x, data.pose.pose.orientation.y, data.pose.pose.orientation.z, data.pose.pose.orientation.w])[2]
    v_x = data.twist.twist.linear.x
    v_y = data.twist.twist.linear.y
    return x, y, theta, v_x, v_y

def callback_left_odom(data):
    '''
    Get left robot data
    '''
    global x_l, y_l, theta_l, v_x_l, v_y_l
    x_l = data.pose.pose.position.x
    y_l = data.pose.pose.position.y
    theta_l = euler_from_quaternion([data.pose.pose.orientation.x, data.pose.pose.orientation.y, data.pose.pose.orientation.z, data.pose.pose.orientation.w])[2]
    v_x_l = data.twist.twist.linear.x
    v_y_l = data.twist.twist.linear.y
    return x_l, y_l, theta_l, v_x_l, v_y_l

def callback_right_odom(data):
    '''
    Get right robot data
    '''
    global x_r, y_r, theta_r, v_x_r, v_y_r
    x_r = data.pose.pose.position.x
    y_r = data.pose.pose.position.y
    theta_r = euler_from_quaternion([data.pose.pose.orientation.x, data.pose.pose.orientation.y, data.pose.pose.orientation.z, data.pose.pose.orientation.w])[2]
    v_x_r = data.twist.twist.linear.x
    v_y_r = data.twist.twist.linear.y
    return x_r, y_r, theta_r, v_x_r, v_y_r

rospy.init_node('assign4_skeleton', anonymous = True)
rospy.Subscriber('/odom', Odometry, callback_odom) #topic name fixed
rospy.Subscriber('/left_odom', Odometry, callback_left_odom) #topic name fixed
rospy.Subscriber('/right_odom', Odometry, callback_right_odom) #topic name fixed

pub_vel = rospy.Publisher('/cmd_vel', Twist, queue_size = 10)
r = rospy.Rate(30)


global i2, i3, i4, i5, i6, i7
i2, i3, i4, i5, i6, i7 = 0, 0, 0, 0, 0, 0
# while True: #replace with balancing reached?
while True:

    #calculate v_x, v_y as per the balancing strategy
    vel_x_gain = 10
    vel_x = vel_x_gain*(0.5*(x_l - x) + 0.5*(x_r - x)) # max value = vel_x_gain*7
    # vel_x = -0.15
    vel_y_gain = -1
    vel_y = vel_y_gain*y
    if theta < 0:
        theta += 2 * math.pi

    #Make sure your velocity vector is feasible (magnitude and direction)
    # taken care by the velodity_convert function

    #convert velocity vector to linear and angular velocties using velocity_convert function given above
    [v_lin, v_ang] = velocity_convert(x, y, theta, vel_x, vel_y)
    
    #publish the velocities below
    vel_msg = Twist()
    vel_msg.linear.x = v_lin
    vel_msg.angular.z = v_ang
    pub_vel.publish(vel_msg)
    print(i2, i3, i4, i5, i6, i7)
    #store robot path with time stamps (data available in odom topic)
    if rospy.get_namespace() == "/bot_2/":
        m = str(str(i2) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_2 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_2.txt", 'a')
        out_file_2.write(m)
        out_file_2.close()
        i2 = i2 + 1
    elif rospy.get_namespace() == "/bot_3/":
        m = str(str(i3) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_3 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_3.txt", 'a')
        out_file_3.write(m)
        out_file_3.close()
        i3 = i3 + 1
    elif rospy.get_namespace() == "/bot_4/":
        m = str(str(i4) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_4 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_4.txt", 'a')
        out_file_4.write(m)
        out_file_4.close()
        i4 = i4 + 1
    elif rospy.get_namespace() == "/bot_5/":
        m = str(str(i5) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_5 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_5.txt", 'a')
        out_file_5.write(m)
        out_file_5.close()
        i5 = i5 + 1
    elif rospy.get_namespace() == "/bot_6/":
        m = str(str(i6) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_6 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_6.txt", 'a')
        out_file_6.write(m)
        out_file_6.close()
        i6 = i6 + 1
    elif rospy.get_namespace() == "/bot_7/":
        m = str(str(i7) + ", " + str(x) + ", " + str(y)) + '\n'
        out_file_7 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_7.txt", 'a')
        out_file_7.write(m)
        out_file_7.close()
        i7 = i7 + 1

    r.sleep()