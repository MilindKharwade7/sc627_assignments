import numpy as np
import matplotlib.pyplot as plt

inp_file_2 = open("rob_2.txt", 'r')
inp_2 = inp_file_2.readlines()
rob_2 = np.zeros((len(inp_2), 3))
for i in range(len(inp_2)):
    t, x, y = inp_2[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_2[i][0] = t
    rob_2[i][1] = x
    rob_2[i][2] = y
inp_file_2.close()

inp_file_3 = open("rob_3.txt", 'r')
inp_3 = inp_file_3.readlines()
rob_3 = np.zeros((len(inp_3), 3))
for i in range(len(inp_3)):
    t, x, y = inp_3[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_3[i][0] = t
    rob_3[i][1] = x
    rob_3[i][2] = y
inp_file_3.close()

inp_file_4 = open("rob_4.txt", 'r')
inp_4 = inp_file_4.readlines()
rob_4 = np.zeros((len(inp_4), 3))
for i in range(len(inp_4)):
    t, x, y = inp_4[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_4[i][0] = t
    rob_4[i][1] = x
    rob_4[i][2] = y
inp_file_4.close()

inp_file_5 = open("rob_5.txt", 'r')
inp_5 = inp_file_5.readlines()
rob_5 = np.zeros((len(inp_5), 3))
for i in range(len(inp_5)):
    t, x, y = inp_5[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_5[i][0] = t
    rob_5[i][1] = x
    rob_5[i][2] = y
inp_file_5.close()

inp_file_6 = open("rob_6.txt", 'r')
inp_6 = inp_file_6.readlines()
rob_6 = np.zeros((len(inp_6), 3))
for i in range(len(inp_6)):
    t, x, y = inp_6[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_6[i][0] = t
    rob_6[i][1] = x
    rob_6[i][2] = y
inp_file_6.close()

inp_file_7 = open("rob_7.txt", 'r')
inp_7 = inp_file_7.readlines()
rob_7 = np.zeros((len(inp_7), 3))
for i in range(len(inp_7)):
    t, x, y = inp_7[i].split(',')
    t, x, y = float(t), float(x), float(y)
    rob_7[i][0] = t
    rob_7[i][1] = x
    rob_7[i][2] = y
inp_file_7.close()

plt.plot(rob_2[8:, 0], rob_2[8:, 1], label = "Robot2")
plt.plot(rob_3[8:, 0], rob_3[8:, 1], label = "Robot3")
plt.plot(rob_4[8:, 0], rob_4[8:, 1], label = "Robot4")
plt.plot(rob_5[8:, 0], rob_5[8:, 1], label = "Robot5")
plt.plot(rob_6[8:, 0], rob_6[8:, 1], label = "Robot6")
plt.plot(rob_7[8:, 0], rob_7[8:, 1], label = "Robot7")
plt.xlabel('time (iteration)')
plt.ylabel('x')
plt.legend()
plt.title('posx_vs_time')
plt.savefig('posx_vs_time.png')
plt.show()


plt.plot(rob_2[8:, 1], rob_2[8:, 2], label = "Robot2")
plt.plot(rob_3[8:, 1], rob_3[8:, 2], label = "Robot3")
plt.plot(rob_4[8:, 1], rob_4[8:, 2], label = "Robot4")
plt.plot(rob_5[8:, 1], rob_5[8:, 2], label = "Robot5")
plt.plot(rob_6[8:, 1], rob_6[8:, 2], label = "Robot6")
plt.plot(rob_7[8:, 1], rob_7[8:, 2], label = "Robot7")
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.title('robot_path')
plt.savefig('robot_path.png')
plt.show()
