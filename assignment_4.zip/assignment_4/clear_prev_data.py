out_file_2 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_2.txt", 'r+')
out_file_2.truncate(0)
out_file_2.close()

out_file_3 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_3.txt", 'r+')
out_file_3.truncate(0)
out_file_3.close()

out_file_4 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_4.txt", 'r+')
out_file_4.truncate(0)
out_file_4.close()

out_file_5 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_5.txt", 'r+')
out_file_5.truncate(0)
out_file_5.close()

out_file_6 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_6.txt", 'r+')
out_file_6.truncate(0)
out_file_6.close()

out_file_7 = open("/home/milind/catkin_ws/src/sc627_assignments/assignment_4/rob_7.txt", 'r+')
out_file_7.truncate(0)
out_file_7.close()