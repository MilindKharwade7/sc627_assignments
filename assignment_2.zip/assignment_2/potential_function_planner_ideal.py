import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
from helper import *

inp_file = open("input.txt", 'r')
inp = inp_file.readlines()

start_x, start_y = inp[0].split(',')
start_x, start_y = float(start_x), float(start_y)
goal_x, goal_y = inp[1].split(',')
goal_x, goal_y = float(goal_x), float(goal_y)
step_size = float(inp[2])
# step_size = 0.01
fac = 0.2  # factor for smoother path
tolerance = 0.01
res = 0.1
buffer = 2
d_goal = 2
chi = 0.8
Q = 2
eta = 0.8
potential_max = 2.5



Polygons = []
i = 4
j = 0
Polygons.append(np.empty((0, 2)))
while i < len(inp):
    if str(inp[i]) == '\n':
        j = j + 1
        Polygons.append(np.empty((0, 2)))
        i = i + 1
        continue
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    Polygons[j] = np.append(Polygons[j], np.array([[x, y]]), axis = 0)
    i = i+1

inp_file.close()


def dist(p, q):
    return np.linalg.norm(p-q)


def potential_field(start, goal, obstaclesList, res, buffer, eta, Q, chi, d_goal):
    
    minx, miny, maxx, maxy = 0, 0, 0, 0
    for i in range(len(obstaclesList)):
        minx = min(minx, min(obstaclesList[i][:, 0]))
        miny = min(miny, min(obstaclesList[i][:, 1]))
        maxx = max(maxx, max(obstaclesList[i][:, 0]))
        maxy = max(maxy, max(obstaclesList[i][:, 1]))
    minx = np.floor(min(minx, start[0], goal[0])) - buffer
    miny = np.floor(min(miny, start[1], goal[1])) - buffer
    maxx = np.ceil(max(maxx, start[0], goal[0])) + buffer
    maxy = np.ceil(max(maxy, start[1], goal[1])) + buffer

    lenx = np.ceil((maxx - minx)/res) + 1
    leny = np.ceil((maxy - miny)/res) + 1
    maxx = (lenx - 1)*res + minx
    maxy = (leny - 1)*res + miny
    lenx = int(lenx)
    leny = int(leny)
    meshx = np.arange(minx, maxx + res, res)
    meshy = np.arange(miny, maxy + res, res)
    meshx, meshy = np.meshgrid(meshx, meshy)
    l = len(obstaclesList)
    potential = np.zeros((3, leny, lenx))
    for i in range(lenx):
        for j in range(leny):
            point = np.array([meshx[j, i], meshy[j, i]])
            d_q = np.inf
            for k in range(l):
                d_q = min(d_q, computeDistancePointToPolygon(point, obstaclesList[k]))
            if d_q <= Q:
                potential[0, j, i] = 0.5*eta*(((1/d_q)-(1/Q))**2)
                potential[0, j, i] = min(potential[0, j, i], potential_max)
            if dist(point, goal) <= d_goal:
                potential[1, j, i] = 0.5*chi*(dist(point, goal))**2
            else:
                potential[1, j, i] = d_goal*chi*dist(point, goal) - 0.5*chi*((d_goal)**2)
    potential[2, :, :] = sum(potential[:2, :, :])
    return potential, meshx, meshy


def descent(start, goal, potential, step_size, fac, meshx, meshy):
    path = np.empty((0, 2))
    path = np.append(path, np.array([start]), axis = 0)
    grad = np.array([1, 1])
    minx = min(meshx[0, :])
    miny = min(meshy[:, 0])
    step = 0
    plt.figure()
    plt.quiver(meshx, meshy, -1*np.gradient(potential[2, :, :])[1], -1*np.gradient(potential[2, :, :])[0])
    plt.plot()
    while np.linalg.norm(grad) > tolerance:
        x, y = path[-1, :]
        ix = round((x - minx) / res)
        iy = round((y - miny) / res)
        grad = np.array([np.gradient(potential[2, :, :])[1][iy, ix], np.gradient(potential[2, :, :])[0][iy, ix]])
        dir = grad/np.linalg.norm(grad)
        # step = min(step_size, np.linalg.norm(grad)*fac)
        path = np.append(path, np.array([np.array([x, y]) - dir*step_size]), axis = 0)
        # path = np.append(path, np.array([np.array([x, y]) - dir*step]), axis = 0)
    return path

start = np.array([start_x, start_y])
goal = np.array([goal_x, goal_y])
# start = np.array([5, -2])
# goal = np.array([-2, -2])
obstaclesList = Polygons
potential, meshx, meshy = potential_field(start, goal, obstaclesList, res, buffer, eta, Q, chi, d_goal)
plt.figure()
ax = plt.axes(projection ='3d')
ax.plot_surface(meshx, meshy, potential[2])

Path = descent(start, goal, potential, step_size, fac, meshx, meshy)

path_str = []
for i in range(len(Path)):
    path_str.append(str(Path[i][0]) + ", " + str(Path[i][1]) + '\n')

out_file = open("output_ideal.txt", 'w+')
out_file.writelines(path_str)
out_file.close()

plt.plot(Path[:, 0], Path[:, 1])
plt.show()

