import numpy as np
import matplotlib.pyplot as plt

def computeLineThroughTwoPoints(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    # if (x1 == x2) and (y1 == y2):
    #     print("Points coincide, no unique solution.")
    #     return
    # elif x1*y2 - x2*y1 == 0:
    #     c = 0
    #     a = 1/(1+(x1/y1)**2)
    #     b = -a*x1/y1
    #     return (a, b, c)        
    # else:
    #     a = y1-y2,
    #     b = x2-x1,
    #     c = (x1-x2)*y1 + (y2-y1)*x1
    #     k = np.sqrt(a**2 + b**2)
    #     a = a/k
    #     b = b/k
    #     c = c/k
    #     # c = np.abs(x1*y2 - x2*y1)/np.sqrt((x1-x2)**2+(y1-y2)**2)
    #     # a = c*(y1-y2)/(x1*y2 - x2*y1)
    #     # b = c*(x2-x1)/(x1*y2 - x2*y1)
    #     return (a, b, c)
    a = y1 - y2
    b = x2 - x1
    c = x1 * y2 - x2 * y1
    k = np.sqrt(a**2 + b**2)
    a = a/k
    b = b/k
    c = c/k
    return a, b, c

def computeDistancePointToLine(q, p1, p2):
    x, y = q
    a, b, c = computeLineThroughTwoPoints(p1, p2)
    d = np.abs((a*x + b*y + c))
    if d == 0:
        print("Point lies on the line")
    return d

def computeDistancePointToSegment(q, p1, p2):
    x, y = q
    a, b, c = computeLineThroughTwoPoints(p1, p2)
    # m = -(a*x + b*y + c)*a/2 + x
    # n = -(a*x + b*y + c)*b/2 + y
    m = b*(b*x - a*y)-a*c
    n = a*(a*y - b*x) - b*c
    if p1[0] != p2[0]:
        if (m - p1[0])*(m - p2[0]) < 0:
            w = 0
            d = computeDistancePointToLine(q, p1, p2)
        elif np.abs(m - p1[0]) < np.abs(m - p2[0]):
            w = 1
            d = np.sqrt((x-p1[0])**2 + (y-p1[1])**2)
        else:
            w = 2
            d = np.sqrt((x-p2[0])**2 + (y-p2[1])**2)
        return (d, w)
    else:
        if (n - p1[1])*(n - p2[1]) < 0:
            w = 0
            d = computeDistancePointToLine(q, p1, p2)
        elif np.abs(n - p1[1]) < np.abs(n - p2[1]):
            w = 1
            d = np.sqrt((x-p1[0])**2 + (y-p1[1])**2)
        else:
            w = 2
            d = np.sqrt((x-p2[0])**2 + (y-p2[1])**2)
        return (d, w)

def computeDistancePointToPolygon(q, P):
    n = P.shape[0]
    d = np.inf*np.ones(n)
    for i in range(n-1):
        d[i] = computeDistancePointToSegment(q, P[i], P[i+1])[0]
    d[n-1] = computeDistancePointToSegment(q, P[n-1], P[0])[0]
    dmin = min(d)
    return dmin

def computeTangentVectorToPolygon(q, P):
    n = P.shape[0]
    d = np.inf*np.ones(n)
    e = np.zeros(n)
    for i in range(n-1):
        d[i], e[i] = computeDistancePointToSegment(q, P[i], P[i+1])
    d[n-1], e[n-1] = computeDistancePointToSegment(q, P[n-1], P[0])
    dmin = min(d)
    i = np.argmin(d)


    if e[i] == 0:
        if i != n-1:
            a, b, c = computeLineThroughTwoPoints(P[i], P[i+1])
        else:
            a, b, c = computeLineThroughTwoPoints(P[i], P[0])
        
        if a*q[0] + b*q[1] + c > 0:
            return -b, a
        else:
            return b, -a
        

    else:
        p = P[i + int(e[i]) - 1]     
        a, b, c = computeLineThroughTwoPoints(p, q)
        return a, b


# my_points = np.array([[0.5, -0.5-0.707], [0.5+0.707, -0.5], [0.5+0.707, 0.5], [0.5, 0.5+0.707], [-0.5, +0.5+0.707], [-0.5-0.707, 0.5], [-0.5-0.707, -0.5], [-0.5, -0.5-0.707]])
# my_shape = plt.Polygon(my_points, fc="r")
# plt.gca().add_patch(my_shape)
# plt.axis([-2, 2, -2, 2])
# # plt.show()
# q = (0.5+0.1, +0.5+0.707+1.1)
# print(computeTangentVectorToPolygon(q, my_points))