#!/usr/bin/env python

from sc627_helper.msg import MoveXYAction, MoveXYGoal, MoveXYResult
import rospy
import actionlib

#import other helper files if any
import numpy as np
import math
from helper import *


rospy.init_node('test', anonymous= True)

#Initialize client
client = actionlib.SimpleActionClient('move_xy', MoveXYAction)
client.wait_for_server()

#read input file
inp_file = open("input.txt", 'r')
inp = inp_file.readlines()
start_x, start_y = inp[0].split(',')
start_x, start_y = float(start_x), float(start_y)
goal_x, goal_y = inp[1].split(',')
goal_x, goal_y = float(goal_x), float(goal_y)
step_size = float(inp[2])
fac = 0.2  # factor for smoother path
tolerance = 0.01
res = 0.1
buffer = 2
d_goal = 2
chi = 0.8
Q = 2
eta = 0.8
potential_max = 2.5
Polygons = []
i = 4
j = 0
Polygons.append(np.empty((0, 2)))
while i < len(inp):
    if str(inp[i]) == '\n':
        j = j + 1
        Polygons.append(np.empty((0, 2)))
        i = i + 1
        continue
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    Polygons[j] = np.append(Polygons[j], np.array([[x, y]]), axis = 0)
    i = i+1
inp_file.close()
start = np.array([start_x, start_y])
goal = np.array([goal_x, goal_y])
obstaclesList = Polygons
grad = np.array([1, 1])
current_position = start

def dist(p, q):
    return np.linalg.norm(p-q)

def potential_field(start, goal, obstaclesList, res, buffer, eta, Q, chi, d_goal):
    
    minx, miny, maxx, maxy = 0, 0, 0, 0
    for i in range(len(obstaclesList)):
        minx = min(minx, min(obstaclesList[i][:, 0]))
        miny = min(miny, min(obstaclesList[i][:, 1]))
        maxx = max(maxx, max(obstaclesList[i][:, 0]))
        maxy = max(maxy, max(obstaclesList[i][:, 1]))
    minx = np.floor(min(minx, start[0], goal[0])) - buffer
    miny = np.floor(min(miny, start[1], goal[1])) - buffer
    maxx = np.ceil(max(maxx, start[0], goal[0])) + buffer
    maxy = np.ceil(max(maxy, start[1], goal[1])) + buffer

    lenx = np.ceil((maxx - minx)/res) + 1
    leny = np.ceil((maxy - miny)/res) + 1
    maxx = (lenx - 1)*res + minx
    maxy = (leny - 1)*res + miny
    lenx = int(lenx)
    leny = int(leny)
    meshx = np.arange(minx, maxx + res, res)
    meshy = np.arange(miny, maxy + res, res)
    meshx, meshy = np.meshgrid(meshx, meshy)
    l = len(obstaclesList)
    potential = np.zeros((3, leny, lenx))
    for i in range(lenx):
        for j in range(leny):
            point = np.array([meshx[j, i], meshy[j, i]])
            d_q = np.inf
            for k in range(l):
                d_q = min(d_q, computeDistancePointToPolygon(point, obstaclesList[k]))
            if d_q <= Q:
                potential[0, j, i] = 0.5*eta*(((1/d_q)-(1/Q))**2)
                potential[0, j, i] = min(potential[0, j, i], potential_max)
            if dist(point, goal) <= d_goal:
                potential[1, j, i] = 0.5*chi*(dist(point, goal))**2
            else:
                potential[1, j, i] = d_goal*chi*dist(point, goal) - 0.5*chi*((d_goal)**2)
    potential[2, :, :] = sum(potential[:2, :, :])
    return potential, meshx, meshy

potential, meshx, meshy = potential_field(start, goal, obstaclesList, res, buffer, eta, Q, chi, d_goal)
minx = min(meshx[0, :])
miny = min(meshy[:, 0])

#setting result as initial location
result = MoveXYResult()
result.pose_final.x = 0
result.pose_final.y = 0
result.pose_final.theta = 0 #in radians (0 to 2pi)


out_file = open("output.txt", 'w+')
# while True: #replace true with termination condition
while np.linalg.norm(grad) > tolerance: #replace true with termination condition

    #determine waypoint based on your algo
    x, y = current_position[0], current_position[1]
    ix = round((x - minx) / res)
    iy = round((y - miny) / res)
    ix = int(ix)
    iy = int(iy)
    grad = np.array([np.gradient(potential[2, :, :])[1][iy, ix], np.gradient(potential[2, :, :])[0][iy, ix]])
    dir = -1*grad/np.linalg.norm(grad)
    step = min(step_size, np.linalg.norm(grad)*fac)
    des = np.array([np.array([x, y]) + dir*step_size])
    #this is a dummy waypoint (replace the part below)
    wp = MoveXYGoal()
    wp.pose_dest.x = des[0][0]
    wp.pose_dest.y = des[0][1]
    wp.pose_dest.theta = math.atan2(dir[1], dir[0]) #theta is the orientation of robot in radians (0 to 2pi)

    #send waypoint to turtlebot3 via move_xy server
    client.send_goal(wp)

    client.wait_for_result()

    #getting updated robot location
    result = client.get_result()
    current_position = np.array([result.pose_final.x, result.pose_final.y])

    #write to output file (replacing the part below)
    print(result.pose_final.x, result.pose_final.y, result.pose_final.theta)
    m = str(result.pose_final.x) + ", " + str(result.pose_final.y) + '\n'
    out_file.write(m)

out_file.close()