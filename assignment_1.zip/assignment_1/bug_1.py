#!/usr/bin/env python

from sc627_helper.msg import MoveXYAction, MoveXYGoal, MoveXYResult
import rospy
import actionlib

#import other helper files if any
import numpy as np
import math
from helper import *


rospy.init_node('test', anonymous= True)

#Initialize client
client = actionlib.SimpleActionClient('move_xy', MoveXYAction)
client.wait_for_server()

#read input file
inp_file = open("input.txt", 'r')
inp = inp_file.readlines()
start_x, start_y = inp[0].split(',')
start_x, start_y = float(start_x), float(start_y)
goal_x, goal_y = inp[1].split(',')
goal_x, goal_y = float(goal_x), float(goal_y)
step_size = float(inp[2])
tolerance = 0.05
k = 1  # factor to reduce step size while circumnavigating
Polygons = []
i = 4
j = 0
Polygons.append(np.empty((0, 2)))
while i < len(inp):
    if str(inp[i]) == '\n':
        j = j + 1
        Polygons.append(np.empty((0, 2)))
        i = i + 1
        continue
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    Polygons[j] = np.append(Polygons[j], np.array([[x, y]]), axis = 0)
    i = i+1
inp_file.close()
start = np.array([start_x, start_y])
goal = np.array([goal_x, goal_y])
obstaclesList = Polygons

#setting result as initial location
result = MoveXYResult()
result.pose_final.x = 0
result.pose_final.y = 0
result.pose_final.theta = 0 #in radians (0 to 2pi)
current_position = start
p_hit_list = np.empty((0, 2))
p_leave_list = np.empty((0, 2))

def circumnavigate(strt, polygon, end, k, p_leave_list):
    curr_pos = strt
    p_leave = np.empty((0, 2))
    p_leave_dist = np.inf
    while np.linalg.norm(strt - curr_pos) < 7*step_size:
        dir = np.array(computeTangentVectorToPolygon(curr_pos, polygon))
        
        curr_pos = curr_pos + dir*step_size/k
        
        #this is a dummy waypoint (replace the part below)
        wp = MoveXYGoal()
        wp.pose_dest.x = curr_pos[0]
        wp.pose_dest.y = curr_pos[1]
        wp.pose_dest.theta = math.atan2(dir[1], dir[0]) #theta is the orientation of robot in radians (0 to 2pi)
        
        #send waypoint to turtlebot3 via move_xy server
        client.send_goal(wp)
        
        client.wait_for_result()
        
        #getting updated robot location
        result = client.get_result()
        
        curr_pos = np.array([result.pose_final.x, result.pose_final.y])
        
        
        #write to output file (replacing the part below)
        print(result.pose_final.x, result.pose_final.y, result.pose_final.theta)
        m = str(result.pose_final.x) + ", " + str(result.pose_final.y) + '\n'
        out_file.write(m)
        if np.linalg.norm(goal - curr_pos) < p_leave_dist:
            p_leave = curr_pos
            p_leave_dist = np.linalg.norm(goal - p_leave)
    print('exited while 1')
    while np.linalg.norm(end - curr_pos) > 6*step_size:
        dir = np.array(computeTangentVectorToPolygon(curr_pos, polygon))
        curr_pos = curr_pos + dir*step_size/k
        #this is a dummy waypoint (replace the part below)
        wp = MoveXYGoal()
        wp.pose_dest.x = curr_pos[0]
        wp.pose_dest.y = curr_pos[1]
        wp.pose_dest.theta = math.atan2(dir[1], dir[0]) #theta is the orientation of robot in radians (0 to 2pi)

        #send waypoint to turtlebot3 via move_xy server
        client.send_goal(wp)

        client.wait_for_result()

        #getting updated robot location
        result = client.get_result()
        curr_pos = np.array([result.pose_final.x, result.pose_final.y])

        #write to output file (replacing the part below)
        print(result.pose_final.x, result.pose_final.y, result.pose_final.theta)
        m = str(result.pose_final.x) + ", " + str(result.pose_final.y) + '\n'
        out_file.write(m)
        if np.linalg.norm(goal - curr_pos) < p_leave_dist:
            p_leave = curr_pos
            p_leave_dist = np.linalg.norm(goal - p_leave)
            print(p_leave)
    print('exited while 2')
    p_leave_list = np.append(p_leave_list, np.array([p_leave]), axis = 0)
    print(p_leave_list)

    wp = MoveXYGoal()
    wp.pose_dest.x = end[0]
    wp.pose_dest.y = end[1]
    wp.pose_dest.theta = math.atan2(dir[1], dir[0]) #theta is the orientation of robot in radians (0 to 2pi)
    
    #send waypoint to turtlebot3 via move_xy server
    client.send_goal(wp)
    
    client.wait_for_result()
    
    #getting updated robot location
    result = client.get_result()
    
    curr_pos = np.array([result.pose_final.x, result.pose_final.y])
    
    
    #write to output file (replacing the part below)
    print(result.pose_final.x, result.pose_final.y, result.pose_final.theta)
    m = str(result.pose_final.x) + ", " + str(result.pose_final.y) + '\n'
    out_file.write(m)
    return curr_pos, p_leave_list


out_file = open("output_1.txt", 'w+')
# while True: #replace true with termination condition
while np.linalg.norm(goal - current_position) > step_size: #replace true with termination condition

    #determine waypoint based on your algo
    goal_direction = (goal - current_position)/np.linalg.norm(goal - current_position)
    candidate_current_position = current_position + (goal_direction*step_size)
    for i in range(len(obstaclesList)):
        if computeDistancePointToPolygon(candidate_current_position, obstaclesList[i]) < tolerance:
            p_hit = current_position
            p_hit_list = np.append(p_hit_list, np.array([p_hit]), axis = 0)
            current_position, p_leave_list = circumnavigate(p_hit, obstaclesList[i], p_hit, k, p_leave_list)
            current_position, p_leave_list = circumnavigate(current_position, obstaclesList[i], p_leave_list[-1], k, p_leave_list)
            goal_direction = (goal - current_position)/np.linalg.norm(goal - current_position)
            candidate_current_position = current_position + (goal_direction*step_size)
    current_position = candidate_current_position
    #this is a dummy waypoint (replace the part below)
    wp = MoveXYGoal()
    wp.pose_dest.x = current_position[0]
    wp.pose_dest.y = current_position[1]
    wp.pose_dest.theta = math.atan2(goal_direction[1], goal_direction[0]) #theta is the orientation of robot in radians (0 to 2pi)

    #send waypoint to turtlebot3 via move_xy server
    client.send_goal(wp)

    client.wait_for_result()

    #getting updated robot location
    result = client.get_result()
    current_position = np.array([result.pose_final.x, result.pose_final.y])

    #write to output file (replacing the part below)
    print(result.pose_final.x, result.pose_final.y, result.pose_final.theta)
    m = str(result.pose_final.x) + ", " + str(result.pose_final.y) + '\n'
    out_file.write(m)

out_file.close()