import numpy as np
import matplotlib.pyplot as plt
from helper import *

inp_file = open("input.txt", 'r')
inp = inp_file.readlines()

start_x, start_y = inp[0].split(',')
start_x, start_y = float(start_x), float(start_y)
goal_x, goal_y = inp[1].split(',')
goal_x, goal_y = float(goal_x), float(goal_y)
step_size = float(inp[2])
tolerance = 0.15


Polygons = []
i = 4
j = 0
Polygons.append(np.empty((0, 2)))
while i < len(inp):
    if str(inp[i]) == '\n':
        j = j + 1
        Polygons.append(np.empty((0, 2)))
        i = i + 1
        continue
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    Polygons[j] = np.append(Polygons[j], np.array([[x, y]]), axis = 0)
    i = i+1

inp_file.close()

def BugBase(start, goal, obstaclesList, step_size):
    path = np.empty((0, 2))
    current_position = start
    path = np.append(path, np.array([start]), axis = 0)
    while np.linalg.norm(goal - current_position) > step_size:
        goal_direction = (goal - current_position)/np.linalg.norm(goal - current_position)
        candidate_current_position = current_position + (goal_direction*step_size)
        for i in range(len(obstaclesList)):
            if computeDistancePointToPolygon(candidate_current_position, obstaclesList[i]) < tolerance:
                return "Failure: There is an obstacle lying between the start and goal", path
        current_position = candidate_current_position
        path = np.append(path, np.array([current_position]), axis = 0)
    path = np.append(path, np.array([goal]), axis = 0)
    return "Success", path


start = np.array([start_x, start_y])
goal = np.array([goal_x, goal_y])
obstaclesList = Polygons
Path = BugBase(start, goal, obstaclesList, step_size)[1]

path_str = []
for i in range(len(Path)):
    path_str.append(str(Path[i][0]) + ", " + str(Path[i][1]) + '\n')

out_file = open("output_base_ideal.txt", 'w+')
out_file.writelines(path_str)
out_file.close()

plt.plot(Path[:, 0], Path[:, 1])
plt.show()