import numpy as np
import matplotlib.pyplot as plt
from helper import *

inp_file = open("input.txt", 'r')
inp = inp_file.readlines()

start_x, start_y = inp[0].split(',')
start_x, start_y = float(start_x), float(start_y)
goal_x, goal_y = inp[1].split(',')
goal_x, goal_y = float(goal_x), float(goal_y)
step_size = float(inp[2])
tolerance = 0.05
k = 5  # factor to reduce step size while circumnavigating



Polygons = []
i = 4
j = 0
Polygons.append(np.empty((0, 2)))
while i < len(inp):
    if str(inp[i]) == '\n':
        j = j + 1
        Polygons.append(np.empty((0, 2)))
        i = i + 1
        continue
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    Polygons[j] = np.append(Polygons[j], np.array([[x, y]]), axis = 0)
    i = i+1

inp_file.close()


def Bug1(start, goal, obstaclesList, step_size):
    path = np.empty((0, 2))
    current_position = start
    path = np.append(path, np.array([start]), axis = 0)
    p_hit_list = np.empty((0, 2))
    p_leave_list = np.empty((0, 2))
    while np.linalg.norm(goal - current_position) > step_size:
        goal_direction = (goal - current_position)/np.linalg.norm(goal - current_position)
        candidate_current_position = current_position + (goal_direction*step_size)
        for i in range(len(obstaclesList)):
            if computeDistancePointToPolygon(candidate_current_position, obstaclesList[i]) < tolerance:
                p_hit = current_position
                p_hit_list = np.append(p_hit_list, np.array([p_hit]), axis = 0)
                path, p_leave = circumnavigate(p_hit, obstaclesList[i], p_hit, step_size, k, path)
                current_position = path[-1, :]
                p_leave_list = np.append(p_leave_list, np.array([p_leave]), axis = 0)
                path, _ = circumnavigate(current_position, obstaclesList[i], p_leave, step_size, k, path)
                current_position = path[-1, :]
                goal_direction = (goal - current_position)/np.linalg.norm(goal - current_position)
                candidate_current_position = current_position + (goal_direction*step_size)
        current_position = candidate_current_position
        path = np.append(path, np.array([current_position]), axis = 0)
    path = np.append(path, np.array([goal]), axis = 0)
    return "Success", path

def circumnavigate(strt, polygon, end, step_size, k, path):
    curr_pos = strt
    p_leave = np.empty((0, 2))
    p_leave_dist = np.inf
    for i in range(k+2):
        curr_pos = curr_pos + np.array(computeTangentVectorToPolygon(curr_pos, polygon))*step_size/k
        path = np.append(path, np.array([curr_pos]), axis = 0)
        if np.linalg.norm(goal - curr_pos) < p_leave_dist:
            p_leave = curr_pos
            p_leave_dist = np.linalg.norm(goal - p_leave)
    while np.linalg.norm(end - curr_pos) >= step_size:
        curr_pos = curr_pos + np.array(computeTangentVectorToPolygon(curr_pos, polygon))*step_size/k
        path = np.append(path, np.array([curr_pos]), axis = 0)
        if np.linalg.norm(goal - curr_pos) < p_leave_dist:
            p_leave = curr_pos
            p_leave_dist = np.linalg.norm(goal - p_leave)
    # cand_curr_pos = curr_pos + computeTangentVectorToPolygon(curr_pos, polygon)*step_size
    # if computeDistancePointToPolygon(cand_curr_pos, obstaclesList[i]) < tolerance:
    #     curr_pos = curr_pos + 
    # computeTangentVectorToPolygon(strt, polygon)
    path = np.append(path, np.array([end]), axis = 0)
    # plt.plot(path[:, 0], path[:, 1])
    # plt.show()
    return path, p_leave


start = np.array([start_x, start_y])
goal = np.array([goal_x, goal_y])
obstaclesList = Polygons
Path = Bug1(start, goal, obstaclesList, step_size)[1]

path_str = []
for i in range(len(Path)):
    path_str.append(str(Path[i][0]) + ", " + str(Path[i][1]) + '\n')

out_file = open("output_1_ideal.txt", 'w+')
out_file.writelines(path_str)
out_file.close()

plt.plot(Path[:, 0], Path[:, 1])
plt.show()
