import numpy as np
import matplotlib.pyplot as plt

inp_file = open("output_1.txt", 'r')
inp = inp_file.readlines()
actual_path = np.empty((0, 2))
for i in range(len(inp)):
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    actual_path = np.append(actual_path, np.array([[x, y]]), axis = 0)
inp_file.close()

inp_file = open("output_1_ideal.txt", 'r')
inp = inp_file.readlines()
ideal_path = np.empty((0, 2))
for i in range(len(inp)):
    x, y = inp[i].split(',')
    x, y = float(x), float(y)
    ideal_path = np.append(ideal_path, np.array([[x, y]]), axis = 0)
inp_file.close()

plt.figure(1)
plt.plot(actual_path[:, 0], actual_path[:, 1])
plt.plot(ideal_path[:, 0], ideal_path[:, 1])
plt.show()